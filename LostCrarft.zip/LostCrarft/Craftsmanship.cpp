#include "StdAfx.h"
#include "Craftsmanship.h"



Craftsmanship::Craftsmanship()
{
}

Craftsmanship::~Craftsmanship()
{
}
